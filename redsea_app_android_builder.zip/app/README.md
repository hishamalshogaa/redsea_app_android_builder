# Red Sea Fish App (Flutter)

## Quick start
1) Install Flutter (3.22+).
2) `flutter pub get`
3) Android: create `android/local.properties` with your SDK path if needed.
4) Run on device: `flutter run`

> Map style now points to a public MapLibre demo. Replace with an offline style/tiles before field use.

## Next steps
- Integrate SQLite DAO for sightings.
- Replace demo map style.
- Connect `InferenceService` to `CameraScreen` capture.
- Add AR/scale reference & refraction correction.
