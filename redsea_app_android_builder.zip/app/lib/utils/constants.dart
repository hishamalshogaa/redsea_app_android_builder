class AppConstants {
  // بدّل هذه الروابط إلى بوابتك (proxy) أو مزودك المباشر
  static const satelliteTileUrl = String.fromEnvironment(
    'SATELLITE_XYZ_URL',
    defaultValue: 'http://YOUR_SERVER:8080/tiles/{z}/{x}/{y}.png',
  );
  static const chlTileUrl = String.fromEnvironment(
    'CHL_XYZ_URL',
    defaultValue: 'http://YOUR_SERVER:8080/chl/{z}/{x}/{y}.png',
  );
  static const sstTileUrl = String.fromEnvironment(
    'SST_XYZ_URL',
    defaultValue: 'http://YOUR_SERVER:8080/sst/{z}/{x}/{y}.png',
  );
  static const turbidityTileUrl = String.fromEnvironment(
    'TURBIDITY_XYZ_URL',
    defaultValue: 'http://YOUR_SERVER:8080/turbidity/{z}/{x}/{y}.png',
  );

  static const reefsGeoJsonAsset = 'assets/data/reef_areas.geojson';
}
