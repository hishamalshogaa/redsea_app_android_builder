class FishSpecies {
  final String id;
  final String commonAr;
  final String commonEn;
  final String latin;
  final double maxLengthCm;
  final double a;
  final double b;

  FishSpecies({
    required this.id,
    required this.commonAr,
    required this.commonEn,
    required this.latin,
    required this.maxLengthCm,
    required this.a,
    required this.b,
  });

  double estimateWeightKg(double lengthCm) {
    // W = a * L^b (grams) -> kg
    final grams = a * (pow(lengthCm, b));
    return grams / 1000.0;
  }
}
