import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/prediction_service.dart';

class AnalysisScreen extends StatefulWidget {
  const AnalysisScreen({super.key});
  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {
  final _lat = TextEditingController(text: '21.5');
  final _lon = TextEditingController(text: '39.2');
  DateTime _date = DateTime.now();
  Map<String, dynamic>? _result;
  bool _busy = false;

  @override
  void dispose() {
    _lat.dispose();
    _lon.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    setState(() { _busy = true; _result = null; });
    final p = PredictionService(baseUrl: 'http://YOUR_SERVER:8080');
    final res = await p.predict(
      lat: double.tryParse(_lat.text) ?? 0,
      lon: double.tryParse(_lon.text) ?? 0,
      date: _date.toUtc(),
    );
    setState(() { _busy = false; _result = res; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تحليل الموقع')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(child: TextField(controller: _lat, decoration: const InputDecoration(labelText: 'خط العرض (lat)'))),
              const SizedBox(width: 12),
              Expanded(child: TextField(controller: _lon, decoration: const InputDecoration(labelText: 'خط الطول (lon)'))),
            ]),
            const SizedBox(height: 12),
            Row(children: [
              Text('التاريخ: ${DateFormat('yyyy-MM-dd').format(_date)}'),
              const SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: () async {
                  final picked = await showDatePicker(
                    context: context,
                    firstDate: DateTime.now().subtract(const Duration(days: 365*5)),
                    lastDate: DateTime.now().add(const Duration(days: 1)),
                    initialDate: _date,
                  );
                  if (picked != null) setState(() => _date = picked);
                },
                icon: const Icon(Icons.date_range),
                label: const Text('اختر تاريخ'),
              )
            ]),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _busy ? null : _run,
              icon: const Icon(Icons.analytics),
              label: const Text('تحليل الاحتمالية'),
            ),
            const SizedBox(height: 16),
            if (_busy) const LinearProgressIndicator(),
            if (_result != null) Expanded(
              child: ListView(
                children: [
                  Text('احتمالية تواجد الأسماك: ${(_result!['presence_prob'] * 100).toStringAsFixed(1)}%'),
                  const SizedBox(height: 8),
                  Text('صحة الشعاب (0..1): ${_result!['reef_health'].toStringAsFixed(2)}'),
                  const SizedBox(height: 8),
                  const Text('أفضل الأنواع المتوقعة:'),
                  ...((_result!['top_species'] as List<dynamic>).map((s) => ListTile(
                    leading: const Icon(Icons.fish),
                    title: Text(s['name']),
                    trailing: Text('${(s['prob']*100).toStringAsFixed(0)}%'),
                  )))
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
