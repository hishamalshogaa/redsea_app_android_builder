import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:maplibre_gl/mapbox_gl.dart';
import '../utils/constants.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});
  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  MaplibreMapController? controller;
  bool satelliteOn = true;
  bool chlOn = false;
  bool sstOn = false;
  bool turbOn = false;
  bool reefsOn = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الخريطة'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.layers_outlined),
            onSelected: (v) async {
              switch (v) {
                case 'sat': setState(() => satelliteOn = !satelliteOn); satelliteOn ? _ensureRaster('satellite') : _removeRaster('satellite'); break;
                case 'chl': setState(() => chlOn = !chlOn); chlOn ? _ensureRaster('chl') : _removeRaster('chl'); break;
                case 'sst': setState(() => sstOn = !sstOn); sstOn ? _ensureRaster('sst') : _removeRaster('sst'); break;
                case 'turb': setState(() => turbOn = !turbOn); turbOn ? _ensureRaster('turbidity') : _removeRaster('turbidity'); break;
                case 'reef': setState(() => reefsOn = !reefsOn); reefsOn ? _ensureReefs() : _removeReefs(); break;
              }
            },
            itemBuilder: (ctx) => [
              CheckedPopupMenuItem(value: 'sat', checked: satelliteOn, child: const Text('قمر صناعي')),
              CheckedPopupMenuItem(value: 'chl', checked: chlOn, child: const Text('كلوروفيل (Chl-a)')),
              CheckedPopupMenuItem(value: 'sst', checked: sstOn, child: const Text('حرارة سطح البحر (SST)')),
              CheckedPopupMenuItem(value: 'turb', checked: turbOn, child: const Text('عكارة')),
              CheckedPopupMenuItem(value: 'reef', checked: reefsOn, child: const Text('الشعاب المرجانية')),
            ],
          )
        ],
      ),
      body: MaplibreMap(
        accessToken: null,
        styleString: 'https://demotiles.maplibre.org/style.json',
        onMapCreated: (c) async {
          controller = c;
          if (satelliteOn) await _ensureRaster('satellite');
          if (reefsOn) await _ensureReefs();
        },
        myLocationEnabled: true,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('بدء تسجيل مشاهدة...'))
          );
        },
        icon: const Icon(Icons.add_location_alt_outlined),
        label: const Text('تسجيل مشاهدة'),
      ),
    );
  }

  Future<void> _ensureRaster(String kind) async {
    if (controller == null) return;
    final sourceId = '${kind}-source';
    final layerId = '${kind}-layer';
    final tiles = {
      'satellite': AppConstants.satelliteTileUrl,
      'chl': AppConstants.chlTileUrl,
      'sst': AppConstants.sstTileUrl,
      'turbidity': AppConstants.turbidityTileUrl,
    }[kind]!;

    final sources = await controller!.getSources();
    final hasSource = sources.any((s) => s['id'] == sourceId);
    if (!hasSource) {
      await controller!.addSource(sourceId, {
        'type': 'raster',
        'tiles': [tiles],
        'tileSize': 256,
      });
    }
    final layers = await controller!.getLayers();
    final hasLayer = layers.any((l) => l['id'] == layerId);
    if (!hasLayer) {
      await controller!.addLayer({'id': layerId, 'type': 'raster', 'source': sourceId});
    }
  }

  Future<void> _removeRaster(String kind) async {
    if (controller == null) return;
    final sourceId = '${kind}-source';
    final layerId = '${kind}-layer';
    final layers = await controller!.getLayers();
    if (layers.any((l) => l['id'] == layerId)) {
      await controller!.removeLayer(layerId);
    }
    final sources = await controller!.getSources();
    if (sources.any((s) => s['id'] == sourceId)) {
      await controller!.removeSource(sourceId);
    }
  }

  Future<void> _ensureReefs() async {
    if (controller == null) return;
    const sourceId = 'reefs-source';
    const layerId = 'reefs-layer';
    final sources = await controller!.getSources();
    final hasSource = sources.any((s) => s['id'] == sourceId);
    if (!hasSource) {
      final geojsonStr = await rootBundle.loadString(AppConstants.reefsGeoJsonAsset);
      await controller!.addSource(sourceId, {
        'type': 'geojson',
        'data': json.decode(geojsonStr),
      });
    }
    final layers = await controller!.getLayers();
    final hasLayer = layers.any((l) => l['id'] == layerId);
    if (!hasLayer) {
      await controller!.addLayer({
        'id': layerId,
        'type': 'fill',
        'source': sourceId,
        'paint': {
          'fill-color': '#00ff88',
          'fill-opacity': 0.25,
        }
      });
    }
  }

  Future<void> _removeReefs() async {
    if (controller == null) return;
    const sourceId = 'reefs-source';
    const layerId = 'reefs-layer';
    final layers = await controller!.getLayers();
    if (layers.any((l) => l['id'] == layerId)) {
      await controller!.removeLayer(layerId);
    }
    final sources = await controller!.getSources();
    if (sources.any((s) => s['id'] == sourceId)) {
      await controller!.removeSource(sourceId);
    }
  }
}
