import 'package:flutter/material.dart';
import 'package:camera/camera.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});
  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  CameraController? _controller;
  late Future<void> _init;

  @override
  void initState() {
    super.initState();
    _init = _setup();
  }

  Future<void> _setup() async {
    final cameras = await availableCameras();
    final cam = cameras.first;
    _controller = CameraController(cam, ResolutionPreset.high, enableAudio: false);
    await _controller!.initialize();
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الكاميرا')),
      body: FutureBuilder(
        future: _init,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          return CameraPreview(_controller!);
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          if (!(_controller?.value.isInitialized ?? false)) return;
          final file = await _controller!.takePicture();
          if (!context.mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('تم الالتقاط: ${file.path}'))
          );
          // TODO: send to on-device model for species detection & size estimation
        },
        child: const Icon(Icons.camera_alt),
      ),
    );
  }
}
