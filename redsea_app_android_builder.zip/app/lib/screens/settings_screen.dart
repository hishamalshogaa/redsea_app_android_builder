import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _server = TextEditingController(text: 'http://YOUR_SERVER:8080');
  @override
  void dispose() { _server.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: _server, decoration: const InputDecoration(labelText: 'خادم البيانات (URL)')),
            const SizedBox(height: 12),
            const Text('يمكن تمرير الروابط أيضاً عبر --dart-define أثناء التشغيل.'),
          ],
        ),
      ),
    );
  }
}
