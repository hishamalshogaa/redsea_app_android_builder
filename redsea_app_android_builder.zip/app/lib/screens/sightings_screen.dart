import 'package:flutter/material.dart';

class SightingsScreen extends StatelessWidget {
  const SightingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: load from local SQLite
    final items = const [
      {'species': 'ناجل', 'depth': 18.4, 'len': 42.0, 'date': '2025-08-16'},
      {'species': 'هامور', 'depth': 12.0, 'len': 55.0, 'date': '2025-08-10'},
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('مشاهداتي')),
      body: ListView.separated(
        itemCount: items.length,
        separatorBuilder: (_, __) => const Divider(height: 0),
        itemBuilder: (context, i) {
          final it = items[i];
          return ListTile(
            leading: const Icon(Icons.fish),
            title: Text(it['species'].toString()),
            subtitle: Text('عمق: ${it['depth']} م | طول: ${it['len']} سم'),
            trailing: Text(it['date'].toString()),
          );
        },
      ),
    );
  }
}
