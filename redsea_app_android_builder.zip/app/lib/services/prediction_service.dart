import 'dart:convert';
import 'package:http/http.dart' as http;

class PredictionService {
  final String baseUrl;
  PredictionService({required this.baseUrl});

  Future<Map<String, dynamic>> predict({required double lat, required double lon, required DateTime date}) async {
    final uri = Uri.parse('$baseUrl/api/v1/predict');
    final resp = await http.post(uri, headers: {'Content-Type':'application/json'}, body: json.encode({
      'lat': lat, 'lon': lon, 'date': date.toIso8601String()
    }));
    if (resp.statusCode != 200) {
      throw Exception('Prediction failed: ${resp.statusCode}');
    }
    return json.decode(resp.body) as Map<String, dynamic>;
  }
}
