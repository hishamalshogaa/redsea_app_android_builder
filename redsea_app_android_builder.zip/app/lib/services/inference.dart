import 'dart:typed_data';
import 'package:tflite_flutter/tflite_flutter.dart';

class InferenceService {
  late Interpreter _interpreter;

  Future<void> loadModel() async {
    _interpreter = await Interpreter.fromAsset('assets/models/sample_model.tflite');
  }

  Future<Map<String, dynamic>> predict(Uint8List imageBytes) async {
    // TODO: preprocess image, run detection/classification
    // This is a placeholder output
    return {
      'species_id': 'plectropomus_areolatus',
      'confidence': 0.82,
      'length_cm_est': 45.5,
      'weight_kg_est': 1.6,
    };
  }
}
