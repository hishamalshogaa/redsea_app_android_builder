import 'dart:convert';
import 'package:http/http.dart' as http;

class SatelliteService {
  final String baseUrl;
  final String? apiKey;

  SatelliteService({required this.baseUrl, this.apiKey});

  Future<Map<String, dynamic>> fetchReefCoverage(String reefId) async {
    final uri = Uri.parse('$baseUrl/api/v1/satellite/reef-coverage?reef_id=$reefId');
    final resp = await http.get(uri, headers: {
      if (apiKey != null) 'Authorization': 'Bearer $apiKey',
    });
    if (resp.statusCode != 200) {
      throw Exception('Failed to load reef coverage: ${resp.statusCode}');
    }
    return json.decode(resp.body) as Map<String, dynamic>;
  }
}
