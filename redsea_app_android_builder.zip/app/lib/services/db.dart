import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class LocalDb {
  static Database? _db;

  static Future<Database> instance() async {
    if (_db != null) return _db!;
    final path = join(await getDatabasesPath(), 'redsea.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, v) async {
        await db.execute('''
          CREATE TABLE IF NOT EXISTS sightings(
            id TEXT PRIMARY KEY,
            timestamp TEXT,
            lat REAL, lon REAL,
            depth_m REAL,
            species_id TEXT,
            count INTEGER,
            length_cm_est REAL,
            weight_kg_est REAL,
            confidence REAL,
            notes TEXT
          );
        ''');
      },
    );
    return _db!;
  }
}
